# Screenshots

Place your MySQL Workbench screenshots here before pushing to GitHub.
See README.md Section 10 ('Suggested Screenshots for Submission') for the exact list and naming convention to use.

